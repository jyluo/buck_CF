public class Hello
{
	public void doHello()
	{
		System.out.println("Hello World");
	}

	public static void main(String[] args)
	{
		new Hello().doHello();
	}
}
